package com.EventHub.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.EventHub.entity.Ticketentity;
import com.EventHub.Repository.TicketRepository;

@Service
public class TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    // Create ticket
    public Ticketentity createTicket(Ticketentity ticket) {

        ticket.setTicketNumber("TICKET-" + System.currentTimeMillis());

        return ticketRepository.save(ticket);
    }

    // Get all tickets
    public List<Ticketentity> getAllTickets() {
        return ticketRepository.findAll();
    }

    // Get ticket by ID
    public Ticketentity getTicketById(Long id) {

        Optional<Ticketentity> ticket = ticketRepository.findById(id);

        return ticket.orElse(null);
    }

    // Delete ticket
    public boolean deleteTicket(Long id) {

        Ticketentity ticket = getTicketById(id);

        if (ticket != null) {

            ticketRepository.deleteById(id);

            return true;
        }

        return false;
    }

    // Get tickets by user
    public List<Ticketentity> getTicketsByUser(String userName) {

        return ticketRepository.findAll()
                .stream()
                .filter(t -> t.getUserName().equalsIgnoreCase(userName))
                .toList();
    }
}