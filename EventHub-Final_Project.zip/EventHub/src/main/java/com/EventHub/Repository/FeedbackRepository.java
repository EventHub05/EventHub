package com.EventHub.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.EventHub.entity.Feedback;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

}