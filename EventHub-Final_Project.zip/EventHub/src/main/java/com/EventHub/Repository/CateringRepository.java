package com.EventHub.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.EventHub.entity.Catering;

public interface CateringRepository extends JpaRepository<Catering, Long> {

}