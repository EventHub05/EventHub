package com.EventHub.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.EventHub.entity.Photographer;

public interface PhotographerRepository extends JpaRepository<Photographer, Long> {

}