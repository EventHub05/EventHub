package com.EventHub.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.EventHub.entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {

    List<Notification> findByUserId(Long userId);
}