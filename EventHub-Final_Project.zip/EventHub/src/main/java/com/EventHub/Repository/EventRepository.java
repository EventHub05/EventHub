package com.EventHub.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.EventHub.entity.Event;

public interface EventRepository extends JpaRepository<Event, Long> {

}