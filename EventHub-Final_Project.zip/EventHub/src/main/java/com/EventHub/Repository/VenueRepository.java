package com.EventHub.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.EventHub.entity.Venue;

public interface VenueRepository extends JpaRepository<Venue, Long> {

}