package com.EventHub.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "bookings")
public class BookingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String eventName;
    private String userName;
    private String serviceType;
    private String eventDate;
    private String status;

    public BookingEntity() {
    }

    public BookingEntity(Long id, String eventName, String userName,
                         String serviceType, String eventDate, String status) {
        this.id = id;
        this.eventName = eventName;
        this.userName = userName;
        this.serviceType = serviceType;
        this.eventDate = eventDate;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public String getEventName() {
        return eventName;
    }

    public String getUserName() {
        return userName;
    }

    public String getServiceType() {
        return serviceType;
    }

    public String getEventDate() {
        return eventDate;
    }

    public String getStatus() {
        return status;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}