package com.EventHub.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.EventHub.entity.Photographer;
import com.EventHub.service.PhotographerService;

@RestController
@RequestMapping("/api/photographers")
public class PhotographerController {

    @Autowired
    private PhotographerService photographerService;

    @GetMapping
    public List<Photographer> getAllPhotographers() {
        return photographerService.getAllPhotographers();
    }

    @PostMapping
    public List<Photographer> addPhotographers(@RequestBody List<Photographer> photographers) {
        return photographerService.saveAllPhotographers(photographers);
    }
}