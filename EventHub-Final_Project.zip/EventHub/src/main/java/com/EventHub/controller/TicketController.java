package com.EventHub.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.EventHub.entity.Ticketentity;
import com.EventHub.service.TicketService;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    @Autowired
    private TicketService ticketService;

    // Create ticket
    @PostMapping("/add")
    public Ticketentity createTicket(@RequestBody Ticketentity ticket) {
        return ticketService.createTicket(ticket);
    }

    // Get all tickets
    @GetMapping("/all")
    public List<Ticketentity> getAllTickets() {
        return ticketService.getAllTickets();
    }

    // Get ticket by ID
    @GetMapping("/{id}")
    public Ticketentity getTicketById(@PathVariable Long id) {
        return ticketService.getTicketById(id);
    }

    // Delete ticket
    @DeleteMapping("/{id}")
    public String deleteTicket(@PathVariable Long id) {

        boolean deleted = ticketService.deleteTicket(id);

        return deleted ? "Ticket deleted successfully" : "Ticket not found";
    }

    // Get tickets by user
    @GetMapping("/user/{username}")
    public List<Ticketentity> getTicketsByUser(@PathVariable("username") String userName) {
        return ticketService.getTicketsByUser(userName);
    }
}